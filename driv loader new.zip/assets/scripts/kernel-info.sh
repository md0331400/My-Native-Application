uname -r

